# Custom Search API Samples

Google Custom Search enables you to create a search engine for your website, your blog, or a collection of websites.

[Getting Started](https://developers.google.com/custom-search/)

## Running the sample

`node customsearch.js`